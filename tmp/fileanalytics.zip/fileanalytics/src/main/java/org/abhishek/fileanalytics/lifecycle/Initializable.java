/* Copyright 2015 Roychoudhury, Abhishek */

package org.abhishek.fileanalytics.lifecycle;

public interface Initializable {
    void initialize();

    boolean intialized();
}
