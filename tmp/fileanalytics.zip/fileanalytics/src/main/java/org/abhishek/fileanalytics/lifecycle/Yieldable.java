/* Copyright 2015 Roychoudhury, Abhishek */

package org.abhishek.fileanalytics.lifecycle;

/**
 * Indicates whether the implementation is an output for some operation.
 * 
 * @author abhishek
 * @since 1.0
 */
public interface Yieldable {

}
